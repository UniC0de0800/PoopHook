﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace ManualMapApi
{
	// Token: 0x02000004 RID: 4
	public class MapInject
	{
		// Token: 0x06000008 RID: 8 RVA: 0x000020B8 File Offset: 0x000002B8
		private static MapInject.IMAGE_OPTIONAL_HEADER toImageOptionalHeader(byte[] byteArray, int offset)
		{
			MapInject.IMAGE_OPTIONAL_HEADER image_OPTIONAL_HEADER;
			image_OPTIONAL_HEADER.Magic = BitConverter.ToUInt16(byteArray, offset);
			image_OPTIONAL_HEADER.MajorLinkerVersion = (byte)BitConverter.ToChar(byteArray, offset + 2);
			image_OPTIONAL_HEADER.MinorLinkerVersion = (byte)BitConverter.ToChar(byteArray, offset + 3);
			image_OPTIONAL_HEADER.SizeOfCode = BitConverter.ToUInt32(byteArray, offset + 4);
			image_OPTIONAL_HEADER.SizeOfInitializedData = BitConverter.ToUInt32(byteArray, offset + 8);
			image_OPTIONAL_HEADER.SizeOfUninitializedData = BitConverter.ToUInt32(byteArray, offset + 12);
			image_OPTIONAL_HEADER.AddressOfEntryPoint = BitConverter.ToUInt32(byteArray, offset + 16);
			image_OPTIONAL_HEADER.BaseOfCode = BitConverter.ToUInt32(byteArray, offset + 20);
			image_OPTIONAL_HEADER.BaseOfData = BitConverter.ToUInt32(byteArray, offset + 24);
			image_OPTIONAL_HEADER.ImageBase = BitConverter.ToUInt32(byteArray, offset + 28);
			image_OPTIONAL_HEADER.SectionAlignment = BitConverter.ToUInt32(byteArray, offset + 32);
			image_OPTIONAL_HEADER.FileAlignment = BitConverter.ToUInt32(byteArray, offset + 36);
			image_OPTIONAL_HEADER.MajorOperatingSystemVersion = BitConverter.ToUInt16(byteArray, offset + 40);
			image_OPTIONAL_HEADER.MinorOperatingSystemVersion = BitConverter.ToUInt16(byteArray, offset + 42);
			image_OPTIONAL_HEADER.MajorImageVersion = BitConverter.ToUInt16(byteArray, offset + 44);
			image_OPTIONAL_HEADER.MinorImageVersion = BitConverter.ToUInt16(byteArray, offset + 46);
			image_OPTIONAL_HEADER.MajorSubsystemVersion = BitConverter.ToUInt16(byteArray, offset + 48);
			image_OPTIONAL_HEADER.MinorSubsystemVersion = BitConverter.ToUInt16(byteArray, offset + 50);
			image_OPTIONAL_HEADER.Win32VersionValue = BitConverter.ToUInt32(byteArray, offset + 52);
			image_OPTIONAL_HEADER.SizeOfImage = BitConverter.ToUInt32(byteArray, offset + 56);
			image_OPTIONAL_HEADER.SizeOfHeaders = BitConverter.ToUInt32(byteArray, offset + 60);
			image_OPTIONAL_HEADER.CheckSum = BitConverter.ToUInt32(byteArray, offset + 64);
			image_OPTIONAL_HEADER.Subsystem = BitConverter.ToUInt16(byteArray, offset + 68);
			image_OPTIONAL_HEADER.DllCharacteristics = BitConverter.ToUInt16(byteArray, offset + 70);
			image_OPTIONAL_HEADER.SizeOfStackReserve = BitConverter.ToUInt32(byteArray, offset + 72);
			image_OPTIONAL_HEADER.SizeOfStackCommit = BitConverter.ToUInt32(byteArray, offset + 76);
			image_OPTIONAL_HEADER.SizeOfHeapReserve = BitConverter.ToUInt32(byteArray, offset + 80);
			image_OPTIONAL_HEADER.SizeOfHeapCommit = BitConverter.ToUInt32(byteArray, offset + 84);
			image_OPTIONAL_HEADER.LoaderFlags = BitConverter.ToUInt32(byteArray, offset + 88);
			image_OPTIONAL_HEADER.NumberOfRvaAndSizes = BitConverter.ToUInt32(byteArray, offset + 92);
			image_OPTIONAL_HEADER.DataDirectory = new MapInject.IMAGE_DATA_DIRECTORY[16];
			for (int i = 0; i < 10; i++)
			{
				MapInject.IMAGE_DATA_DIRECTORY image_DATA_DIRECTORY;
				image_DATA_DIRECTORY.VirtualAddress = BitConverter.ToUInt32(byteArray, offset + (96 + i * 8));
				image_DATA_DIRECTORY.Size = BitConverter.ToUInt32(byteArray, offset + (96 + i * 8) + 4);
				image_OPTIONAL_HEADER.DataDirectory[i] = image_DATA_DIRECTORY;
			}
			return image_OPTIONAL_HEADER;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00002314 File Offset: 0x00000514
		private static MapInject.IMAGE_FILE_HEADER toImageFileHeader(byte[] byteArray, int offset)
		{
			MapInject.IMAGE_FILE_HEADER result;
			result.Machine = BitConverter.ToUInt16(byteArray, offset);
			result.NumberOfSections = BitConverter.ToUInt16(byteArray, offset + 2);
			result.TimeDateStamp = BitConverter.ToUInt32(byteArray, offset + 4);
			result.PointerToSymbolTable = BitConverter.ToUInt32(byteArray, offset + 8);
			result.NumberOfSymbols = BitConverter.ToUInt32(byteArray, offset + 12);
			result.SizeOfOptionalHeader = BitConverter.ToUInt16(byteArray, offset + 16);
			result.Characteristics = BitConverter.ToUInt16(byteArray, offset + 18);
			return result;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002394 File Offset: 0x00000594
		private static MapInject.IMAGE_DOS_HEADER toImageDosHeader(byte[] byteArray, int offset)
		{
			MapInject.IMAGE_DOS_HEADER image_DOS_HEADER;
			image_DOS_HEADER.e_magic = BitConverter.ToUInt16(byteArray, offset);
			image_DOS_HEADER.e_cblp = BitConverter.ToUInt16(byteArray, offset + 2);
			image_DOS_HEADER.e_cp = BitConverter.ToUInt16(byteArray, offset + 4);
			image_DOS_HEADER.e_crlc = BitConverter.ToUInt16(byteArray, offset + 6);
			image_DOS_HEADER.e_cparhdr = BitConverter.ToUInt16(byteArray, offset + 8);
			image_DOS_HEADER.e_minalloc = BitConverter.ToUInt16(byteArray, offset + 10);
			image_DOS_HEADER.e_maxalloc = BitConverter.ToUInt16(byteArray, offset + 12);
			image_DOS_HEADER.e_ss = BitConverter.ToUInt16(byteArray, offset + 14);
			image_DOS_HEADER.e_sp = BitConverter.ToUInt16(byteArray, offset + 16);
			image_DOS_HEADER.e_csum = BitConverter.ToUInt16(byteArray, offset + 18);
			image_DOS_HEADER.e_ip = BitConverter.ToUInt16(byteArray, offset + 20);
			image_DOS_HEADER.e_cs = BitConverter.ToUInt16(byteArray, offset + 22);
			image_DOS_HEADER.e_lfarlc = BitConverter.ToUInt16(byteArray, offset + 24);
			image_DOS_HEADER.e_ovno = BitConverter.ToUInt16(byteArray, offset + 26);
			image_DOS_HEADER.e_res = new ushort[4];
			image_DOS_HEADER.e_res[0] = BitConverter.ToUInt16(byteArray, offset + 28);
			image_DOS_HEADER.e_res[1] = BitConverter.ToUInt16(byteArray, offset + 30);
			image_DOS_HEADER.e_res[2] = BitConverter.ToUInt16(byteArray, offset + 32);
			image_DOS_HEADER.e_res[3] = BitConverter.ToUInt16(byteArray, offset + 34);
			image_DOS_HEADER.e_oemid = BitConverter.ToUInt16(byteArray, offset + 36);
			image_DOS_HEADER.e_oeminfo = BitConverter.ToUInt16(byteArray, offset + 38);
			image_DOS_HEADER.e_res2 = new ushort[10];
			image_DOS_HEADER.e_res2[0] = BitConverter.ToUInt16(byteArray, offset + 40);
			image_DOS_HEADER.e_res2[1] = BitConverter.ToUInt16(byteArray, offset + 42);
			image_DOS_HEADER.e_res2[2] = BitConverter.ToUInt16(byteArray, offset + 44);
			image_DOS_HEADER.e_res2[3] = BitConverter.ToUInt16(byteArray, offset + 46);
			image_DOS_HEADER.e_res2[4] = BitConverter.ToUInt16(byteArray, offset + 48);
			image_DOS_HEADER.e_res2[5] = BitConverter.ToUInt16(byteArray, offset + 50);
			image_DOS_HEADER.e_res2[6] = BitConverter.ToUInt16(byteArray, offset + 52);
			image_DOS_HEADER.e_res2[7] = BitConverter.ToUInt16(byteArray, offset + 54);
			image_DOS_HEADER.e_res2[8] = BitConverter.ToUInt16(byteArray, offset + 56);
			image_DOS_HEADER.e_res2[9] = BitConverter.ToUInt16(byteArray, offset + 58);
			image_DOS_HEADER.e_lfanew = BitConverter.ToUInt32(byteArray, offset + 60);
			return image_DOS_HEADER;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x000025D4 File Offset: 0x000007D4
		private static MapInject.IMAGE_NT_HEADERS toImageNtHeaders(byte[] byteArray, int offset)
		{
			MapInject.IMAGE_NT_HEADERS result;
			result.Signature = BitConverter.ToUInt32(byteArray, offset);
			result.FileHeader = MapInject.toImageFileHeader(byteArray, offset + 4);
			result.OptionalHeader = MapInject.toImageOptionalHeader(byteArray, offset + 24);
			return result;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002614 File Offset: 0x00000814
		private static MapInject.IMAGE_SECTION_HEADER toImageSectionHeader(byte[] byteArray, int offset)
		{
			MapInject.IMAGE_SECTION_HEADER image_SECTION_HEADER;
			image_SECTION_HEADER.Name = new byte[8];
			for (int i = 0; i < 8; i++)
			{
				image_SECTION_HEADER.Name[i] = (byte)BitConverter.ToChar(byteArray, offset + i);
			}
			image_SECTION_HEADER.PhysicalAddressOrVirtualSize = BitConverter.ToUInt32(byteArray, offset + 8);
			image_SECTION_HEADER.VirtualAddress = BitConverter.ToUInt32(byteArray, offset + 12);
			image_SECTION_HEADER.SizeOfRawData = BitConverter.ToUInt32(byteArray, offset + 16);
			image_SECTION_HEADER.PointerToRawData = BitConverter.ToUInt32(byteArray, offset + 20);
			image_SECTION_HEADER.PointerToRelocations = BitConverter.ToUInt32(byteArray, offset + 24);
			image_SECTION_HEADER.PointerToLinenumbers = BitConverter.ToUInt32(byteArray, offset + 28);
			image_SECTION_HEADER.NumberOfRelocations = BitConverter.ToUInt16(byteArray, offset + 32);
			image_SECTION_HEADER.NumberOfLinenumbers = BitConverter.ToUInt16(byteArray, offset + 36);
			image_SECTION_HEADER.Characteristics = BitConverter.ToUInt32(byteArray, offset + 40);
			return image_SECTION_HEADER;
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000026E5 File Offset: 0x000008E5
		private static byte[] makePayload()
		{
			return new byte[]
			{
				85,
				139,
				236,
				131,
				236,
				96,
				131,
				125,
				8,
				0,
				117,
				15,
				139,
				69,
				8,
				199,
				64,
				12,
				64,
				64,
				64,
				0,
				233,
				117,
				2,
				0,
				0,
				139,
				77,
				8,
				139,
				81,
				8,
				137,
				85,
				252,
				139,
				69,
				252,
				139,
				72,
				60,
				139,
				85,
				252,
				141,
				68,
				10,
				24,
				137,
				69,
				244,
				139,
				77,
				8,
				139,
				17,
				137,
				85,
				196,
				139,
				69,
				8,
				139,
				72,
				4,
				137,
				77,
				208,
				139,
				85,
				244,
				139,
				69,
				252,
				3,
				66,
				16,
				137,
				69,
				164,
				139,
				77,
				244,
				139,
				85,
				252,
				43,
				81,
				28,
				137,
				85,
				216,
				15,
				132,
				195,
				0,
				0,
				0,
				184,
				8,
				0,
				0,
				0,
				107,
				200,
				5,
				139,
				85,
				244,
				131,
				124,
				10,
				100,
				0,
				117,
				15,
				139,
				69,
				8,
				199,
				64,
				12,
				96,
				96,
				96,
				0,
				233,
				12,
				2,
				0,
				0,
				185,
				8,
				0,
				0,
				0,
				107,
				209,
				5,
				139,
				69,
				244,
				139,
				77,
				252,
				3,
				76,
				16,
				96,
				137,
				77,
				240,
				139,
				85,
				240,
				131,
				58,
				0,
				15,
				132,
				129,
				0,
				0,
				0,
				139,
				69,
				240,
				139,
				72,
				4,
				131,
				233,
				8,
				209,
				233,
				137,
				77,
				200,
				139,
				85,
				240,
				131,
				194,
				8,
				137,
				85,
				224,
				199,
				69,
				220,
				0,
				0,
				0,
				0,
				235,
				18,
				139,
				69,
				220,
				131,
				192,
				1,
				137,
				69,
				220,
				139,
				77,
				224,
				131,
				193,
				2,
				137,
				77,
				224,
				139,
				85,
				220,
				59,
				85,
				200,
				116,
				54,
				139,
				69,
				224,
				15,
				183,
				8,
				193,
				249,
				12,
				131,
				249,
				3,
				117,
				38,
				139,
				85,
				240,
				139,
				69,
				252,
				3,
				2,
				139,
				77,
				224,
				15,
				183,
				17,
				129,
				226,
				byte.MaxValue,
				15,
				0,
				0,
				3,
				194,
				137,
				69,
				212,
				139,
				69,
				212,
				139,
				8,
				3,
				77,
				216,
				139,
				85,
				212,
				137,
				10,
				235,
				176,
				139,
				69,
				240,
				139,
				77,
				240,
				3,
				72,
				4,
				137,
				77,
				240,
				233,
				115,
				byte.MaxValue,
				byte.MaxValue,
				byte.MaxValue,
				186,
				8,
				0,
				0,
				0,
				193,
				226,
				0,
				139,
				69,
				244,
				131,
				124,
				16,
				100,
				0,
				15,
				132,
				220,
				0,
				0,
				0,
				185,
				8,
				0,
				0,
				0,
				193,
				225,
				0,
				139,
				85,
				244,
				139,
				69,
				252,
				3,
				68,
				10,
				96,
				137,
				69,
				236,
				139,
				77,
				236,
				131,
				121,
				12,
				0,
				15,
				132,
				186,
				0,
				0,
				0,
				139,
				85,
				236,
				139,
				69,
				252,
				3,
				66,
				12,
				137,
				69,
				192,
				139,
				77,
				196,
				137,
				77,
				188,
				139,
				85,
				192,
				82,
				byte.MaxValue,
				85,
				188,
				137,
				69,
				204,
				139,
				69,
				236,
				139,
				77,
				252,
				3,
				8,
				137,
				77,
				248,
				139,
				85,
				236,
				139,
				69,
				252,
				3,
				66,
				16,
				137,
				69,
				232,
				131,
				125,
				248,
				0,
				117,
				6,
				139,
				77,
				232,
				137,
				77,
				248,
				235,
				18,
				139,
				85,
				248,
				131,
				194,
				4,
				137,
				85,
				248,
				139,
				69,
				232,
				131,
				192,
				4,
				137,
				69,
				232,
				139,
				77,
				248,
				131,
				57,
				0,
				116,
				81,
				139,
				85,
				248,
				139,
				2,
				37,
				0,
				0,
				0,
				128,
				116,
				31,
				139,
				77,
				208,
				137,
				77,
				184,
				139,
				85,
				248,
				139,
				2,
				37,
				byte.MaxValue,
				byte.MaxValue,
				0,
				0,
				80,
				139,
				77,
				204,
				81,
				byte.MaxValue,
				85,
				184,
				139,
				85,
				232,
				137,
				2,
				235,
				36,
				139,
				69,
				248,
				139,
				77,
				252,
				3,
				8,
				137,
				77,
				180,
				139,
				85,
				208,
				137,
				85,
				176,
				139,
				69,
				180,
				131,
				192,
				2,
				80,
				139,
				77,
				204,
				81,
				byte.MaxValue,
				85,
				176,
				139,
				85,
				232,
				137,
				2,
				235,
				149,
				139,
				69,
				236,
				131,
				192,
				20,
				137,
				69,
				236,
				233,
				57,
				byte.MaxValue,
				byte.MaxValue,
				byte.MaxValue,
				185,
				8,
				0,
				0,
				0,
				107,
				209,
				9,
				139,
				69,
				244,
				131,
				124,
				16,
				100,
				0,
				116,
				76,
				185,
				8,
				0,
				0,
				0,
				107,
				209,
				9,
				139,
				69,
				244,
				139,
				77,
				252,
				3,
				76,
				16,
				96,
				137,
				77,
				172,
				139,
				85,
				172,
				139,
				66,
				12,
				137,
				69,
				228,
				235,
				9,
				139,
				77,
				228,
				131,
				193,
				4,
				137,
				77,
				228,
				131,
				125,
				228,
				0,
				116,
				29,
				139,
				85,
				228,
				131,
				58,
				0,
				116,
				21,
				139,
				69,
				228,
				139,
				8,
				137,
				77,
				168,
				106,
				0,
				106,
				1,
				139,
				85,
				252,
				82,
				byte.MaxValue,
				85,
				168,
				235,
				212,
				139,
				69,
				164,
				137,
				69,
				160,
				106,
				0,
				106,
				1,
				139,
				77,
				252,
				81,
				byte.MaxValue,
				85,
				160,
				139,
				85,
				8,
				139,
				69,
				252,
				137,
				66,
				12,
				139,
				229,
				93,
				194,
				4,
				0
			};
		}

		// Token: 0x0600000E RID: 14 RVA: 0x000026FC File Offset: 0x000008FC
		public static bool ManualMap(Process proc, string filepath)
		{
			int num = MapInject.Imports.OpenProcess(2035711U, false, proc.Id);
			if (num == 0)
			{
				throw new Exception("Could not open process");
			}
			byte[] array = File.ReadAllBytes(filepath);
			MapInject.IMAGE_DOS_HEADER image_DOS_HEADER = MapInject.toImageDosHeader(array, 0);
			if (image_DOS_HEADER.e_magic != 23117)
			{
				throw new Exception("Invalid file type");
			}
			MapInject.IMAGE_NT_HEADERS image_NT_HEADERS = MapInject.toImageNtHeaders(array, (int)image_DOS_HEADER.e_lfanew);
			MapInject.IMAGE_OPTIONAL_HEADER optionalHeader = image_NT_HEADERS.OptionalHeader;
			MapInject.IMAGE_FILE_HEADER fileHeader = image_NT_HEADERS.FileHeader;
			if (fileHeader.Machine != 332)
			{
				throw new Exception("Invalid platform");
			}
			int num2 = MapInject.Imports.VirtualAllocEx(num, 0, 4096, 12288U, 64U);
			int num3 = MapInject.Imports.VirtualAllocEx(num, 0, (int)optionalHeader.SizeOfImage, 12288U, 64U);
			if (num3 == 0 || num2 == 0)
			{
				throw new Exception("Target process memory allocation failed (ex) [Error Code: " + MapInject.Imports.GetLastError().ToString() + "]");
			}
			MapInject.MANUAL_MAPPING_DATA manual_MAPPING_DATA;
			manual_MAPPING_DATA.pLoadLibraryA = MapInject.Imports.GetProcAddress(MapInject.Imports.GetModuleHandle("KERNEL32.dll"), "LoadLibraryA");
			manual_MAPPING_DATA.pGetProcAddress = MapInject.Imports.GetProcAddress(MapInject.Imports.GetModuleHandle("KERNEL32.dll"), "GetProcAddress");
			manual_MAPPING_DATA.pbase = num3;
			manual_MAPPING_DATA.hMod = 0;
			int num4 = 0;
			if (MapInject.Imports.WriteProcessMemory(num, num3, array, 4096, ref num4) == 0)
			{
				throw new Exception("Can't write file header [Error Code: " + MapInject.Imports.GetLastError().ToString() + "]");
			}
			int e_lfanew = (int)image_DOS_HEADER.e_lfanew;
			int num5 = e_lfanew + 24 + (int)image_NT_HEADERS.FileHeader.SizeOfOptionalHeader;
			uint num6 = 0U;
			while (num6 != (uint)fileHeader.NumberOfSections)
			{
				MapInject.IMAGE_SECTION_HEADER image_SECTION_HEADER = MapInject.toImageSectionHeader(array, num5);
				if (image_SECTION_HEADER.SizeOfRawData != 0U)
				{
					byte[] array2 = new byte[image_SECTION_HEADER.SizeOfRawData];
					for (int i = 0; i < (int)image_SECTION_HEADER.SizeOfRawData; i++)
					{
						array2[i] = array[(int)(checked((IntPtr)(unchecked((ulong)image_SECTION_HEADER.PointerToRawData + (ulong)((long)i)))))];
					}
					if (MapInject.Imports.WriteProcessMemory(num, num3 + (int)image_SECTION_HEADER.VirtualAddress, array2, array2.Length, ref num4) == 0)
					{
						throw new Exception("Can't map sections [Error Code: " + MapInject.Imports.GetLastError().ToString() + "]");
					}
				}
				num6 += 1U;
				num5 += 40;
			}
			int num7 = MapInject.Imports.VirtualAllocEx(num, 0, 16, 4096U, 4U);
			if (num7 == 0)
			{
				throw new Exception("Target process mapping allocation failed (ex) [Error Code: " + MapInject.Imports.GetLastError().ToString() + "]");
			}
			MapInject.Imports.WriteProcessMemory(num, num7, BitConverter.GetBytes(manual_MAPPING_DATA.pLoadLibraryA), 4, ref num4);
			MapInject.Imports.WriteProcessMemory(num, num7 + 4, BitConverter.GetBytes(manual_MAPPING_DATA.pGetProcAddress), 4, ref num4);
			MapInject.Imports.WriteProcessMemory(num, num7 + 8, BitConverter.GetBytes(manual_MAPPING_DATA.pbase), 4, ref num4);
			MapInject.Imports.WriteProcessMemory(num, num7 + 12, BitConverter.GetBytes(manual_MAPPING_DATA.hMod), 4, ref num4);
			if (num2 == 0)
			{
				throw new Exception("Memory shellcode allocation failed (ex) [Error Code: " + MapInject.Imports.GetLastError().ToString() + "]");
			}
			byte[] array3 = MapInject.makePayload();
			if (MapInject.Imports.WriteProcessMemory(num, num2, array3, array3.Length, ref num4) == 0)
			{
				throw new Exception("Can't write shellcode [Error Code: " + MapInject.Imports.GetLastError().ToString() + "]");
			}
			int num8 = 0;
			int num9 = MapInject.Imports.CreateRemoteThread(num, 0, 0U, num2, num7, 0U, out num8);
			if (num9 == 0 || num8 == 0)
			{
				throw new Exception("Thread creation failed [Error Code: " + MapInject.Imports.GetLastError().ToString() + "]");
			}
			MapInject.Imports.CloseHandle(num9);
			int num10 = 0;
			while (num10 == 0)
			{
				uint num11 = 0U;
				MapInject.Imports.GetExitCodeProcess(num, out num11);
				if (num11 != 259U)
				{
					throw new Exception("Process crashed, exit code: " + num11.ToString());
				}
				byte[] array4 = new byte[16];
				if (MapInject.Imports.ReadProcessMemory(num, num7, array4, 16, ref num4) == 0)
				{
					throw new Exception("Failed to read process memory");
				}
				MapInject.MANUAL_MAPPING_DATA manual_MAPPING_DATA2;
				manual_MAPPING_DATA2.pLoadLibraryA = BitConverter.ToInt32(array4, 0);
				manual_MAPPING_DATA2.pGetProcAddress = BitConverter.ToInt32(array4, 4);
				manual_MAPPING_DATA2.pbase = BitConverter.ToInt32(array4, 8);
				manual_MAPPING_DATA2.hMod = BitConverter.ToInt32(array4, 12);
				num10 = manual_MAPPING_DATA2.hMod;
				if (num10 == 4210752)
				{
					throw new Exception("Wrong mapping ptr");
				}
				if (num10 == 6316128)
				{
					throw new Exception("Wrong directory base relocation");
				}
				Thread.Sleep(10);
			}
			byte[] array5 = new byte[4096];
			Array.Clear(array5, 0, array5.Length);
			if (MapInject.Imports.WriteProcessMemory(num, num3, array5, 4096, ref num4) == 0)
			{
				throw new Exception("Failed to erase file header(s)");
			}
			byte[] array6 = new byte[1048576];
			Array.Clear(array6, 0, array6.Length);
			num5 = e_lfanew + 24 + (int)image_NT_HEADERS.FileHeader.SizeOfOptionalHeader;
			uint num12 = 0U;
			while (num12 != (uint)fileHeader.NumberOfSections)
			{
				MapInject.IMAGE_SECTION_HEADER image_SECTION_HEADER2 = MapInject.toImageSectionHeader(array, num5);
				if (image_SECTION_HEADER2.SizeOfRawData != 0U)
				{
					string text = "";
					byte[] array7 = new byte[16];
					MapInject.Imports.ReadProcessMemory(num, num5, array7, 16, ref num4);
					int num13 = 0;
					while (num13 < 16 && array7[num13] >= 32 && array7[num13] < 127)
					{
						string str = text;
						char c = (char)array7[num13];
						text = str + c.ToString();
						num13++;
					}
					if ((text == ".pdata" || text == ".rsrc" || text == ".reloc") && MapInject.Imports.WriteProcessMemory(num, num3 + (int)image_SECTION_HEADER2.VirtualAddress, array6, (int)image_SECTION_HEADER2.SizeOfRawData, ref num4) == 0)
					{
						throw new Exception(string.Concat(new string[]
						{
							"Can't clear section ",
							text,
							" [Error code: ",
							MapInject.Imports.GetLastError().ToString(),
							"]"
						}));
					}
				}
				num12 += 1U;
				num5 += 40;
			}
			return true;
		}

		// Token: 0x04000004 RID: 4
		private const int IMAGE_NUMBEROF_DIRECTORY_ENTRIES = 16;

		// Token: 0x04000005 RID: 5
		private const ushort IMAGE_FILE_MACHINE_I386 = 332;

		// Token: 0x04000006 RID: 6
		private const ushort CURRENT_ARCH = 332;

		// Token: 0x04000007 RID: 7
		private const uint STATUS_PENDING = 259U;

		// Token: 0x04000008 RID: 8
		private const uint STILL_ACTIVE = 259U;

		// Token: 0x02000008 RID: 8
		private class Imports
		{
			// Token: 0x06000019 RID: 25
			[DllImport("kernel32.dll")]
			public static extern int OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

			// Token: 0x0600001A RID: 26
			[DllImport("kernel32.dll")]
			public static extern int ReadProcessMemory(int hProcess, int lpBaseAddress, byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesRead);

			// Token: 0x0600001B RID: 27
			[DllImport("kernel32.dll")]
			public static extern int WriteProcessMemory(int hProcess, int lpBaseAddress, byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesWritten);

			// Token: 0x0600001C RID: 28
			[DllImport("kernel32.dll")]
			public static extern int VirtualProtectEx(int hProcess, int lpBaseAddress, int dwSize, uint new_protect, ref uint lpOldProtect);

			// Token: 0x0600001D RID: 29
			[DllImport("kernel32.dll")]
			public static extern int VirtualQueryEx(int hProcess, int lpAddress, out MapInject.Imports.MEMORY_BASIC_INFORMATION lpBuffer, uint dwLength);

			// Token: 0x0600001E RID: 30
			[DllImport("kernel32.dll")]
			public static extern int VirtualAllocEx(int hProcess, int lpAddress, int size, uint allocation_type, uint protect);

			// Token: 0x0600001F RID: 31
			[DllImport("kernel32.dll")]
			public static extern int VirtualFreeEx(int hProcess, int lpAddress, int size, uint allocation_type);

			// Token: 0x06000020 RID: 32
			[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
			public static extern int GetModuleHandle(string lpModuleName);

			// Token: 0x06000021 RID: 33
			[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
			public static extern int GetProcAddress(int hModule, string procName);

			// Token: 0x06000022 RID: 34
			[DllImport("kernel32.dll")]
			public static extern uint GetLastError();

			// Token: 0x06000023 RID: 35
			[DllImport("kernel32.dll", SetLastError = true)]
			public static extern bool CloseHandle(int hObject);

			// Token: 0x06000024 RID: 36
			[DllImport("kernel32.dll", SetLastError = true)]
			[return: MarshalAs(UnmanagedType.Bool)]
			public static extern bool GetExitCodeProcess(int hProcess, out uint lpExitCode);

			// Token: 0x06000025 RID: 37
			[DllImport("kernel32.dll")]
			public static extern int CreateRemoteThread(int hProcess, int lpThreadAttributes, uint dwStackSize, int lpStartAddress, int lpParameter, uint dwCreationFlags, out int lpThreadId);

			// Token: 0x04000010 RID: 16
			public const uint PAGE_NOACCESS = 1U;

			// Token: 0x04000011 RID: 17
			public const uint PAGE_READONLY = 2U;

			// Token: 0x04000012 RID: 18
			public const uint PAGE_READWRITE = 4U;

			// Token: 0x04000013 RID: 19
			public const uint PAGE_WRITECOPY = 8U;

			// Token: 0x04000014 RID: 20
			public const uint PAGE_EXECUTE = 16U;

			// Token: 0x04000015 RID: 21
			public const uint PAGE_EXECUTE_READ = 32U;

			// Token: 0x04000016 RID: 22
			public const uint PAGE_EXECUTE_READWRITE = 64U;

			// Token: 0x04000017 RID: 23
			public const uint PAGE_EXECUTE_WRITECOPY = 128U;

			// Token: 0x04000018 RID: 24
			public const uint PAGE_GUARD = 256U;

			// Token: 0x04000019 RID: 25
			public const uint PAGE_NOCACHE = 512U;

			// Token: 0x0400001A RID: 26
			public const uint PAGE_WRITECOMBINE = 1024U;

			// Token: 0x0400001B RID: 27
			public const uint MEM_COMMIT = 4096U;

			// Token: 0x0400001C RID: 28
			public const uint MEM_RESERVE = 8192U;

			// Token: 0x0400001D RID: 29
			public const uint MEM_DECOMMIT = 16384U;

			// Token: 0x0400001E RID: 30
			public const uint MEM_RELEASE = 32768U;

			// Token: 0x0400001F RID: 31
			public const uint PROCESS_WM_READ = 16U;

			// Token: 0x04000020 RID: 32
			public const uint PROCESS_ALL_ACCESS = 2035711U;

			// Token: 0x04000021 RID: 33
			public const int EXCEPTION_CONTINUE_EXECUTION = -1;

			// Token: 0x04000022 RID: 34
			public const int EXCEPTION_CONTINUE_SEARCH = 0;

			// Token: 0x02000013 RID: 19
			public struct MEMORY_BASIC_INFORMATION
			{
				// Token: 0x04000073 RID: 115
				public int BaseAddress;

				// Token: 0x04000074 RID: 116
				public int AllocationBase;

				// Token: 0x04000075 RID: 117
				public uint AllocationProtect;

				// Token: 0x04000076 RID: 118
				public int RegionSize;

				// Token: 0x04000077 RID: 119
				public uint State;

				// Token: 0x04000078 RID: 120
				public uint Protect;

				// Token: 0x04000079 RID: 121
				public uint Type;
			}
		}

		// Token: 0x02000009 RID: 9
		private struct IMAGE_DATA_DIRECTORY
		{
			// Token: 0x04000023 RID: 35
			public uint VirtualAddress;

			// Token: 0x04000024 RID: 36
			public uint Size;
		}

		// Token: 0x0200000A RID: 10
		private struct IMAGE_OPTIONAL_HEADER
		{
			// Token: 0x04000025 RID: 37
			public ushort Magic;

			// Token: 0x04000026 RID: 38
			public byte MajorLinkerVersion;

			// Token: 0x04000027 RID: 39
			public byte MinorLinkerVersion;

			// Token: 0x04000028 RID: 40
			public uint SizeOfCode;

			// Token: 0x04000029 RID: 41
			public uint SizeOfInitializedData;

			// Token: 0x0400002A RID: 42
			public uint SizeOfUninitializedData;

			// Token: 0x0400002B RID: 43
			public uint AddressOfEntryPoint;

			// Token: 0x0400002C RID: 44
			public uint BaseOfCode;

			// Token: 0x0400002D RID: 45
			public uint BaseOfData;

			// Token: 0x0400002E RID: 46
			public uint ImageBase;

			// Token: 0x0400002F RID: 47
			public uint SectionAlignment;

			// Token: 0x04000030 RID: 48
			public uint FileAlignment;

			// Token: 0x04000031 RID: 49
			public ushort MajorOperatingSystemVersion;

			// Token: 0x04000032 RID: 50
			public ushort MinorOperatingSystemVersion;

			// Token: 0x04000033 RID: 51
			public ushort MajorImageVersion;

			// Token: 0x04000034 RID: 52
			public ushort MinorImageVersion;

			// Token: 0x04000035 RID: 53
			public ushort MajorSubsystemVersion;

			// Token: 0x04000036 RID: 54
			public ushort MinorSubsystemVersion;

			// Token: 0x04000037 RID: 55
			public uint Win32VersionValue;

			// Token: 0x04000038 RID: 56
			public uint SizeOfImage;

			// Token: 0x04000039 RID: 57
			public uint SizeOfHeaders;

			// Token: 0x0400003A RID: 58
			public uint CheckSum;

			// Token: 0x0400003B RID: 59
			public ushort Subsystem;

			// Token: 0x0400003C RID: 60
			public ushort DllCharacteristics;

			// Token: 0x0400003D RID: 61
			public uint SizeOfStackReserve;

			// Token: 0x0400003E RID: 62
			public uint SizeOfStackCommit;

			// Token: 0x0400003F RID: 63
			public uint SizeOfHeapReserve;

			// Token: 0x04000040 RID: 64
			public uint SizeOfHeapCommit;

			// Token: 0x04000041 RID: 65
			public uint LoaderFlags;

			// Token: 0x04000042 RID: 66
			public uint NumberOfRvaAndSizes;

			// Token: 0x04000043 RID: 67
			public MapInject.IMAGE_DATA_DIRECTORY[] DataDirectory;
		}

		// Token: 0x0200000B RID: 11
		private struct IMAGE_FILE_HEADER
		{
			// Token: 0x04000044 RID: 68
			public ushort Machine;

			// Token: 0x04000045 RID: 69
			public ushort NumberOfSections;

			// Token: 0x04000046 RID: 70
			public uint TimeDateStamp;

			// Token: 0x04000047 RID: 71
			public uint PointerToSymbolTable;

			// Token: 0x04000048 RID: 72
			public uint NumberOfSymbols;

			// Token: 0x04000049 RID: 73
			public ushort SizeOfOptionalHeader;

			// Token: 0x0400004A RID: 74
			public ushort Characteristics;
		}

		// Token: 0x0200000C RID: 12
		private struct IMAGE_DOS_HEADER
		{
			// Token: 0x0400004B RID: 75
			public ushort e_magic;

			// Token: 0x0400004C RID: 76
			public ushort e_cblp;

			// Token: 0x0400004D RID: 77
			public ushort e_cp;

			// Token: 0x0400004E RID: 78
			public ushort e_crlc;

			// Token: 0x0400004F RID: 79
			public ushort e_cparhdr;

			// Token: 0x04000050 RID: 80
			public ushort e_minalloc;

			// Token: 0x04000051 RID: 81
			public ushort e_maxalloc;

			// Token: 0x04000052 RID: 82
			public ushort e_ss;

			// Token: 0x04000053 RID: 83
			public ushort e_sp;

			// Token: 0x04000054 RID: 84
			public ushort e_csum;

			// Token: 0x04000055 RID: 85
			public ushort e_ip;

			// Token: 0x04000056 RID: 86
			public ushort e_cs;

			// Token: 0x04000057 RID: 87
			public ushort e_lfarlc;

			// Token: 0x04000058 RID: 88
			public ushort e_ovno;

			// Token: 0x04000059 RID: 89
			public ushort[] e_res;

			// Token: 0x0400005A RID: 90
			public ushort e_oemid;

			// Token: 0x0400005B RID: 91
			public ushort e_oeminfo;

			// Token: 0x0400005C RID: 92
			public ushort[] e_res2;

			// Token: 0x0400005D RID: 93
			public uint e_lfanew;
		}

		// Token: 0x0200000D RID: 13
		private struct IMAGE_NT_HEADERS
		{
			// Token: 0x0400005E RID: 94
			public uint Signature;

			// Token: 0x0400005F RID: 95
			public MapInject.IMAGE_FILE_HEADER FileHeader;

			// Token: 0x04000060 RID: 96
			public MapInject.IMAGE_OPTIONAL_HEADER OptionalHeader;
		}

		// Token: 0x0200000E RID: 14
		private struct MANUAL_MAPPING_DATA
		{
			// Token: 0x04000061 RID: 97
			public int pLoadLibraryA;

			// Token: 0x04000062 RID: 98
			public int pGetProcAddress;

			// Token: 0x04000063 RID: 99
			public int pbase;

			// Token: 0x04000064 RID: 100
			public int hMod;
		}

		// Token: 0x0200000F RID: 15
		private struct IMAGE_SECTION_HEADER
		{
			// Token: 0x04000065 RID: 101
			public byte[] Name;

			// Token: 0x04000066 RID: 102
			public uint PhysicalAddressOrVirtualSize;

			// Token: 0x04000067 RID: 103
			public uint VirtualAddress;

			// Token: 0x04000068 RID: 104
			public uint SizeOfRawData;

			// Token: 0x04000069 RID: 105
			public uint PointerToRawData;

			// Token: 0x0400006A RID: 106
			public uint PointerToRelocations;

			// Token: 0x0400006B RID: 107
			public uint PointerToLinenumbers;

			// Token: 0x0400006C RID: 108
			public ushort NumberOfRelocations;

			// Token: 0x0400006D RID: 109
			public ushort NumberOfLinenumbers;

			// Token: 0x0400006E RID: 110
			public uint Characteristics;
		}
	}
}
