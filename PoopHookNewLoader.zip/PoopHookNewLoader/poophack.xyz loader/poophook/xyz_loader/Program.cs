﻿using System;
using System.Windows.Forms;

namespace poophook.xyz_loader
{
	// Token: 0x02000006 RID: 6
	internal static class Program
	{
		// Token: 0x06000018 RID: 24 RVA: 0x000034E0 File Offset: 0x000016E0
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1());
		}
	}
}
