﻿namespace poophook.xyz_loader
{
	// Token: 0x02000005 RID: 5
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000014 RID: 20 RVA: 0x00002F60 File Offset: 0x00001160
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002F80 File Offset: 0x00001180
		private void InitializeComponent()
		{
			this.button1 = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.stat = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.label2 = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.button1.BackColor = global::System.Drawing.Color.Black;
			this.button1.Font = new global::System.Drawing.Font("Consolas", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.button1.ForeColor = global::System.Drawing.Color.White;
			this.button1.Location = new global::System.Drawing.Point(185, 128);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(124, 32);
			this.button1.TabIndex = 0;
			this.button1.Text = "inject movement";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.button2.BackColor = global::System.Drawing.Color.Black;
			this.button2.Font = new global::System.Drawing.Font("Consolas", 9.75f);
			this.button2.ForeColor = global::System.Drawing.Color.White;
			this.button2.ImageAlign = global::System.Drawing.ContentAlignment.BottomCenter;
			this.button2.Location = new global::System.Drawing.Point(185, 166);
			this.button2.Name = "button2";
			this.button2.Size = new global::System.Drawing.Size(124, 64);
			this.button2.TabIndex = 1;
			this.button2.Text = "inject legacy (open 2k18 csgo first)";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.stat.AutoSize = true;
			this.stat.Font = new global::System.Drawing.Font("Consolas", 15.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.stat.Location = new global::System.Drawing.Point(12, 296);
			this.stat.Name = "stat";
			this.stat.Size = new global::System.Drawing.Size(94, 24);
			this.stat.TabIndex = 3;
			this.stat.Text = "Status:";
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Consolas", 15.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label1.ImageAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.label1.Location = new global::System.Drawing.Point(193, 9);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(106, 24);
			this.label1.TabIndex = 4;
			this.label1.Text = "poophook";
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Consolas", 15.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label2.Location = new global::System.Drawing.Point(472, 9);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(46, 24);
			this.label2.TabIndex = 5;
			this.label2.Text = "[X]";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(18, 19, 20);
			base.ClientSize = new global::System.Drawing.Size(519, 329);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.stat);
			base.Controls.Add(this.button2);
			base.Controls.Add(this.button1);
			this.ForeColor = global::System.Drawing.Color.White;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Form1";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.Load += new global::System.EventHandler(this.Form1_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000009 RID: 9
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400000A RID: 10
		private global::System.Windows.Forms.Button button1;

		// Token: 0x0400000B RID: 11
		private global::System.Windows.Forms.Button button2;

		// Token: 0x0400000C RID: 12
		private global::System.Windows.Forms.Label stat;

		// Token: 0x0400000D RID: 13
		private global::System.Windows.Forms.Label label1;

		// Token: 0x0400000E RID: 14
		private global::System.Windows.Forms.Label label2;
	}
}
