﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using ManualMapApi;

namespace poophook.xyz_loader
{
	// Token: 0x02000005 RID: 5
	public partial class Form1 : Form
	{
		// Token: 0x06000010 RID: 16 RVA: 0x00002CBE File Offset: 0x00000EBE
		public Form1()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002CCC File Offset: 0x00000ECC
		private void Form1_Load(object sender, EventArgs e)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			graphicsPath.AddArc(0, 0, 20, 20, 180f, 90f);
			graphicsPath.AddLine(20, 0, base.Width - 20, 0);
			graphicsPath.AddArc(base.Width - 20, 0, 20, 20, 270f, 90f);
			graphicsPath.AddLine(base.Width, 20, base.Width, base.Height - 20);
			graphicsPath.AddArc(base.Width - 20, base.Height - 20, 20, 20, 0f, 90f);
			graphicsPath.AddLine(base.Width - 20, base.Height, 20, base.Height);
			graphicsPath.AddArc(0, base.Height - 20, 20, 20, 90f, 90f);
			graphicsPath.CloseFigure();
			base.Region = new Region(graphicsPath);
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002DB8 File Offset: 0x00000FB8
		private void button1_Click(object sender, EventArgs e)
		{
			Form1.<>c__DisplayClass2_0 CS$<>8__locals1;
			CS$<>8__locals1.<>4__this = this;
			this.stat.Text = "Status: downloading dll";
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "poophook temp");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			string address = "https://github.com/eveeechu1337/poophook/raw/main/poophook.dll";
			CS$<>8__locals1.filePath = Path.Combine(text, "cheat.dll");
			using (WebClient webClient = new WebClient())
			{
				webClient.DownloadFile(address, CS$<>8__locals1.filePath);
			}
			if (Process.GetProcessesByName("csgo").Length != 0)
			{
				this.stat.Text = "Status: CSGO Has been found!";
				Thread.Sleep(2000);
				this.<button1_Click>g__Inject|2_0(ref CS$<>8__locals1);
				return;
			}
			this.stat.Text = "Status: Starting csgo";
			Process.Start("steam://rungameid/730");
			Thread.Sleep(25000);
			this.<button1_Click>g__Inject|2_0(ref CS$<>8__locals1);
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002EA4 File Offset: 0x000010A4
		private void button2_Click(object sender, EventArgs e)
		{
			Form1.<>c__DisplayClass3_0 CS$<>8__locals1;
			CS$<>8__locals1.<>4__this = this;
			this.stat.Text = "Status: downloading dll";
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "poophook temp");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			string address = "https://github.com/eveeechu1337/poophook/raw/main/legacy.dll";
			CS$<>8__locals1.filePath = Path.Combine(text, "cheat.dll");
			using (WebClient webClient = new WebClient())
			{
				webClient.DownloadFile(address, CS$<>8__locals1.filePath);
			}
			if (Process.GetProcessesByName("csgo").Length != 0)
			{
				this.stat.Text = "Status: CSGO Has been found!";
				Thread.Sleep(2000);
				this.<button2_Click>g__Inject|3_0(ref CS$<>8__locals1);
			}
		}

		// Token: 0x06000016 RID: 22 RVA: 0x000033C8 File Offset: 0x000015C8
		[CompilerGenerated]
		private void <button1_Click>g__Inject|2_0(ref Form1.<>c__DisplayClass2_0 A_1)
		{
			this.stat.Text = "Status: Injected!";
			MapInject.ManualMap(Process.GetProcessesByName("csgo")[0], A_1.filePath);
			if (File.Exists(A_1.filePath))
			{
				try
				{
					File.Delete(A_1.filePath);
					Console.WriteLine("File deleted successfully.");
					return;
				}
				catch (IOException ex)
				{
					Console.WriteLine("Error deleting file: " + ex.Message);
					return;
				}
			}
			Console.WriteLine("File does not exist.");
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00003454 File Offset: 0x00001654
		[CompilerGenerated]
		private void <button2_Click>g__Inject|3_0(ref Form1.<>c__DisplayClass3_0 A_1)
		{
			this.stat.Text = "Status: Injected!";
			MapInject.ManualMap(Process.GetProcessesByName("csgo")[0], A_1.filePath);
			if (File.Exists(A_1.filePath))
			{
				try
				{
					File.Delete(A_1.filePath);
					Console.WriteLine("File deleted successfully.");
					return;
				}
				catch (IOException ex)
				{
					Console.WriteLine("Error deleting file: " + ex.Message);
					return;
				}
			}
			Console.WriteLine("File does not exist.");
		}
	}
}
